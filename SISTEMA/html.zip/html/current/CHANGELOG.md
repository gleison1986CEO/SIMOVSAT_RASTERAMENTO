# Changelog

## [3.2.3.2] - 2019-03-18
### Added
- Load sensor.
- Report: Loading / Unloading.
- Report: Custom overspeed. (enable via plugin)
