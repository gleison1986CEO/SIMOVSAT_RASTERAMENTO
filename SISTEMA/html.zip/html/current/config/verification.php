<?php

return [
    'autologin' => env('VERIFICATION_AUTOLOGIN', false),
    'redirect' => env('VERIFICATION_REDIRECT', ''),
];
