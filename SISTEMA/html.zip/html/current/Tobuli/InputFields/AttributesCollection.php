<?php


namespace Tobuli\InputFields;


use Illuminate\Support\Collection;

class AttributesCollection extends Collection
{

}