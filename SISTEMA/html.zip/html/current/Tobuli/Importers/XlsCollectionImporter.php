<?php
namespace Tobuli\Importers;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;

class XlsCollectionImporter implements ToCollection
{
    public function collection(Collection $rows)
    {
        
    }
}
