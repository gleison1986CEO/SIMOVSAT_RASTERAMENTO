@extends('Frontend.Layouts.frontend')

@section('content')
    <div class="panel">
        <div class="panel-body">
            <h1 class="headline-big">Disabled</h1>

            <div class="alert alert-danger alert-dismissible">
                Server has been suspended, please contact administrator.
            </div>
        </div>
    </div>
@stop