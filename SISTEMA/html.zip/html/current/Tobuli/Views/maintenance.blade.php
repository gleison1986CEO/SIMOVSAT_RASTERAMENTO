<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="GPS Tracking System - Powered by Seosmart Ecuador">
    <link rel="shortcut icon" href="http://localhost/favicon.ico" type="image/x-icon">
    <title>GPS Tracking & Fleet Management System</title>
</head>
<body>
    <div style="text-align: center">
        Hello,<br>
        we would like to inform you that we will update our software and servers in the next few hours. Expected downtime is 1-2 hours. Sorry for inconveniences.
    </div>
</body>
</html>

