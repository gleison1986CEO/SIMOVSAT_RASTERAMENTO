<?php
/**
 * Created by PhpStorm.
 * User: Linas
 * Date: 11/30/2017
 * Time: 4:47 PM
 */

namespace Tobuli\Protocols;


interface Protocol
{

}